AFRAME.registerComponent("wall", {
    init: function () {
      //starting x position
      posX = -20;
      //starting z-position
      posZ = 85;
  
      for (var i = 0; i < 10; i++) {
        //create wire-fence entity
        var wall1 = document.createElement("a-entity");
        var wall2 = document.createElement("a-entity");
        var wall3 = document.createElement("a-entity");
        var wall4 = document.createElement("a-entity");
        var wall5 = document.createElement("a-entity");
        var wall6 = document.createElement("a-entity");
        var wall7 = document.createElement("a-entity");
        var wall8 = document.createElement("a-entity");
        var wall9 = document.createElement("a-entity");
        var wall10 = document.createElement("a-entity");
        var wall11 = document.createElement("a-entity");
        var wall12 = document.createElement("a-entity");
        var wall13 = document.createElement("a-entity");
        var wall14 = document.createElement("a-entity");
        var wall15 = document.createElement("a-entity");
        var wall16 = document.createElement("a-entity");
        var wall17 = document.createElement("a-entity");
        var wall18 = document.createElement("a-entity");
        var wall19 = document.createElement("a-entity");
  
  
        //set x, y and z position
        posX = posX + 5;
        posY = 2.5;
        posZ = posZ - 10;
  
        //scale 
        var scale = { x: 2, y: 2, z: 2 };
  
        //set the id
        wall1.setAttribute("id", "wall1" + i);
        wall2.setAttribute("id", "wall2" + i);
        wall3.setAttribute("id", "wall3" + i);
        wall4.setAttribute("id", "wall4" + i);
        wall5.setAttribute("id", "wall5" + i);
        wall6.setAttribute("id", "wall6" + i);
        wall7.setAttribute("id", "wall7" + i);
        wall8.setAttribute("id", "wall8" + i);
        wall9.setAttribute("id", "wall9" + i);
        wall10.setAttribute("id", "wall10" + i);
        wall11.setAttribute("id", "wall11" + i);
        wall12.setAttribute("id", "wall12" + i);
        wall13.setAttribute("id", "wall13" + i);
        wall14.setAttribute("id", "wall14" + i);
        wall15.setAttribute("id", "wall15" + i);
        wall16.setAttribute("id", "wall16" + i);
        wall17.setAttribute("id", "wall17" + i);
        wall18.setAttribute("id", "wall18" + i);
        wall19.setAttribute("id", "wall19" + i);
  
  
        //set the scale
        wall1.setAttribute("scale", scale);
        wall2.setAttribute("scale", scale);
        wall3.setAttribute("scale", scale);
        wall4.setAttribute("scale", scale);
        wall5.setAttribute("scale", scale);
        wall6.setAttribute("scale", scale);
        wall7.setAttribute("scale", scale);
        wall8.setAttribute("scale", scale);
        wall9.setAttribute("scale", scale);
        wall10.setAttribute("scale", scale);
        wall11.setAttribute("scale", scale);
        wall12.setAttribute("scale", scale);
        wall13.setAttribute("scale", scale);
        wall14.setAttribute("scale", scale);
        wall15.setAttribute("scale", scale);
        wall16.setAttribute("scale", scale);
        wall17.setAttribute("scale", scale);
        wall18.setAttribute("scale", scale);
        wall19.setAttribute("scale", scale);
  
  
        //set the rotation
        wall3.setAttribute("rotation", { x: 0, y: 90, z: 0 });
        wall4.setAttribute("rotation", { x: 0, y: 90, z: 0 });
  
        //set the physics body
        wall1.setAttribute("static-body", {});
        wall2.setAttribute("static-body", {});
        wall3.setAttribute("static-body", {});
        wall4.setAttribute("static-body", {});
        wall5.setAttribute("static-body", {});
        wall6.setAttribute("static-body", {});
        wall7.setAttribute("static-body", {});
        wall8.setAttribute("static-body", {});
        wall9.setAttribute("static-body", {});
        wall10.setAttribute("static-body", {});
        wall11.setAttribute("static-body", {});
        wall12.setAttribute("static-body", {});
        wall13.setAttribute("static-body", {});
        wall14.setAttribute("static-body", {});
        wall15.setAttribute("static-body", {});
        wall16.setAttribute("static-body", {});
        wall17.setAttribute("static-body", {});
        wall18.setAttribute("static-body", {});
        wall19.setAttribute("static-body", {});

  
        var sceneEl = document.querySelector("#scene");
         //attach the entity to the scene
        sceneEl.appendChild(wall1);
        sceneEl.appendChild(wall2);
        sceneEl.appendChild(wall3);
        sceneEl.appendChild(wall4);
        sceneEl.appendChild(wall5);
        sceneEl.appendChild(wall6);
        sceneEl.appendChild(wall7);
        sceneEl.appendChild(wall8);
        sceneEl.appendChild(wall9);
        sceneEl.appendChild(wall10);
        sceneEl.appendChild(wall11);
        sceneEl.appendChild(wall12);
        sceneEl.appendChild(wall13);
        sceneEl.appendChild(wall14);
        sceneEl.appendChild(wall15);
        sceneEl.appendChild(wall16);
        sceneEl.appendChild(wall17);
        sceneEl.appendChild(wall18);
        sceneEl.appendChild(wall19);
  
      }
    },
  });
  
  //boxes
  //UPDATE the component code here
  AFRAME.registerComponent("boxes", {
    schema: {
      height: { type: "number", default: 3 },
      width: { type: "number", default: 3 },
      depth: { type: "number", default: 3 },
    },
    init: function () {
      //keep the loop counter very less if the scene is not loading
      for (var i = 0; i < 20; i++) {
  
        var box = document.createElement("a-entity");
        box.setAttribute("id", "box" + i); 
  
        //set position attribute
        posX = Math.random()*200 -100;
        posY = 1.5;
        posZ =Math.random()*200 -100;
        position= {x:posX, y:posY, z:posZ}
        box.setAttribute("position", position)
        
  
        //set geometry attribute
        box.setAttribute("geometry", {
          primitive: "box", height: this.data.height, width: this.data.width, depth: this.data.depth,
        })
  
        //set material attribute
        box.setAttribute("material", {
          src: "/PRO-C163-Student-Activity-main/images/boxtexture1.jpg",
          repeat: "1 1 1"
        })
  
        // set static-body attribute
        box.setAttribute("static-body", {})
  
        //append the box to the scene
        var sceneEl = document.querySelector("#scene")
        sceneEl.appendChild(box)
      }
    },
  });
  
  